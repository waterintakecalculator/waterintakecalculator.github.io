(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var form = $('wic-form');
  if (!form) { return; }

  var LB = 0.45359237;
  var unit = 'metric';
  var weightEl = $('weight'), ageEl = $('age'), lifeEl = $('life'), actEl = $('activity'), climEl = $('climate');
  var errEl = $('wic-error'), resEl = $('wic-result');
  var btns = document.querySelectorAll('.seg button');

  var BASE = { u18: 45, adult: 35, senior: 33 };            // ml per kg
  var ACT = [0, 300, 600, 900, 1300];                       // ml added
  var CLIM = [1, 1, 1.10, 1.20];                            // multiplier
  var LIFE = { standard: 0, pregnant: 300, breastfeeding: 700 }; // ml added
  var ACT_NAME = ['Sedentary', 'Light activity', 'Moderate activity', 'Very active', 'Athlete / 2x per day'];
  var CLIM_NAME = ['Cool climate', 'Moderate climate', 'Hot climate (+10%)', 'Very hot climate (+20%)'];

  function setUnit(u) {
    var v = parseFloat(weightEl.value);
    if (u !== unit && !isNaN(v)) {
      weightEl.value = (u === 'imperial' ? (v / LB) : (v * LB)).toFixed(1).replace(/\.0$/, '');
    }
    unit = u;
    weightEl.min = u === 'metric' ? 20 : 44;
    weightEl.max = u === 'metric' ? 300 : 660;
    weightEl.placeholder = u === 'metric' ? 'e.g. 70' : 'e.g. 154';
    $('weight-unit').textContent = u === 'metric' ? 'kg' : 'lbs';
    for (var i = 0; i < btns.length; i++) {
      btns[i].setAttribute('aria-pressed', btns[i].getAttribute('data-unit') === u ? 'true' : 'false');
    }
  }
  for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener('click', function () { setUnit(this.getAttribute('data-unit')); });
  }

  function fmt(n, d) {
    return n.toLocaleString('en-US', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 });
  }
  function glassSvg() {
    return '<svg viewBox="0 0 24 32" aria-hidden="true"><path class="fill" d="M4.3 12h15.4l-.9 15.6a2.4 2.4 0 0 1-2.4 2.2H7.6a2.4 2.4 0 0 1-2.4-2.2z"/><path class="out" d="M3 2h18l-2.1 25.8a3.2 3.2 0 0 1-3.2 2.9H8.3a3.2 3.2 0 0 1-3.2-2.9z"/></svg>';
  }

  function calc() {
    errEl.textContent = '';
    var w = parseFloat(weightEl.value);
    var kg = unit === 'metric' ? w : w * LB;
    if (isNaN(w) || kg < 20 || kg > 300) {
      errEl.textContent = unit === 'metric'
        ? 'Please enter a weight between 20 and 300 kg.'
        : 'Please enter a weight between 44 and 660 lbs.';
      weightEl.focus();
      resEl.hidden = true;
      return;
    }
    var age = ageEl.value, life = lifeEl.value;
    var perKg = BASE[age];
    var base = kg * perKg;
    if (age === 'u18' && base < 1200) { base = 1200; }
    var act = ACT[+actEl.value];
    var clim = CLIM[+climEl.value];
    var sub = base + act;
    var climAdd = sub * (clim - 1);
    var lifeAdd = LIFE[life];
    var total = sub + climAdd + lifeAdd;
    total = Math.max(1200, Math.min(8000, total));
    total = Math.round(total / 10) * 10;

    var L = total / 1000, oz = total / 29.5735, cups = total / 236.588;
    var glasses = total / 250, b500 = total / 500;
    var n = Math.ceil(glasses), shown = Math.min(n, 24), g = '';
    for (var k = 0; k < shown; k++) { g += glassSvg(); }
    if (n > shown) { g += '<span class="more">+' + (n - shown) + '</span>'; }
    var gapMin = Math.round((16 * 60) / glasses / 5) * 5;
    var litersFmt = fmt(L, 2).replace(/0$/, '');

    var tip = 'Fill a 1 L bottle ' + (L <= 1.2 ? 'once' : (Math.ceil(L) + ' times')) + ' today and finish one every ~' +
      Math.round(16 / L) + ' hours of the day. That works out to about one 250 ml glass every ' + gapMin + ' minutes while you are awake.';
    if (life === 'pregnant') { tip = 'Sip steadily instead of gulping; small glasses between meals are easier on nausea and heartburn. ' + tip; }
    if (life === 'breastfeeding') { tip = 'Keep a full glass next to your usual feeding spot and drink during each feed. ' + tip; }
    if (+actEl.value >= 3) { tip = 'On training days add 400–800 ml per hour of exercise and replace sweat losses. ' + tip; }
    if (age === 'senior') { tip = 'Thirst weakens with age, so drink on a schedule rather than waiting to feel thirsty. ' + tip; }

    resEl.innerHTML =
      '<div class="res-top"><div><p class="res-label">Your daily water goal</p>' +
      '<p class="res-main">' + litersFmt + '<small>liters</small></p>' +
      '<p class="res-sub">' + fmt(oz) + ' fl oz &middot; ' + fmt(total) + ' ml</p></div>' +
      '<div class="btn-row" style="margin:0"><a class="btn" href="#schedule">See my hourly schedule</a>' +
      '<a class="btn alt" href="#chart">Compare by weight</a></div></div>' +
      '<ul class="units">' +
      '<li><strong>' + fmt(glasses, 1) + '</strong><span>glasses (250 ml)</span></li>' +
      '<li><strong>' + fmt(cups, 1) + '</strong><span>cups (8 fl oz)</span></li>' +
      '<li><strong>' + fmt(b500, 1) + '</strong><span>bottles (500 ml)</span></li>' +
      '<li><strong>' + fmt(L, 1) + '</strong><span>bottles (1 liter)</span></li></ul>' +
      '<div class="glasses" role="img" aria-label="' + n + ' glasses of water">' + g + '</div>' +
      '<p class="cap">Each glass icon = 250 ml (about 8.5 fl oz).</p>' +
      '<table class="break"><tbody>' +
      '<tr><td>Baseline (' + perKg + ' ml &times; ' + fmt(kg, 1) + ' kg)</td><td>' + fmt(Math.round(base)) + ' ml</td></tr>' +
      '<tr><td>Activity: ' + ACT_NAME[+actEl.value] + '</td><td>+' + fmt(act) + ' ml</td></tr>' +
      '<tr><td>' + CLIM_NAME[+climEl.value] + '</td><td>+' + fmt(Math.round(climAdd)) + ' ml</td></tr>' +
      (lifeAdd ? '<tr><td>' + (life === 'pregnant' ? 'Pregnancy' : 'Breastfeeding') + '</td><td>+' + fmt(lifeAdd) + ' ml</td></tr>' : '') +
      '</tbody></table>' +
      '<p class="tip"><strong>Pro tip:</strong> ' + tip + '</p>' +
      '<p class="note">Estimate only, not medical advice. Water-rich foods usually supply about 20% of total daily fluid on top of this. ' +
      'If you have kidney, heart or liver conditions, ask your doctor before changing your fluid intake. See our <a href="/terms.html">Terms</a>.</p>';
    resEl.hidden = false;

    var rows = document.querySelectorAll('.sched li[data-pct]');
    for (var r = 0; r < rows.length; r++) {
      var ml = Math.round(total * (+rows[r].getAttribute('data-pct')) / 100 / 10) * 10;
      rows[r].querySelector('.amt').innerHTML = fmt(ml) + ' ml<span class="pct">' + fmt(ml / 29.5735, 1) + ' fl oz</span>';
    }
    var sg = $('sched-goal');
    if (sg) { sg.textContent = 'Personalized for your goal of ' + litersFmt + ' L (' + fmt(oz) + ' fl oz).'; }

    if (window.matchMedia && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      resEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  form.addEventListener('submit', function (e) { e.preventDefault(); calc(); });
  form.addEventListener('reset', function () {
    setTimeout(function () { setUnit('metric'); resEl.hidden = true; errEl.textContent = ''; }, 0);
  });

  var pb = $('print-chart');
  if (pb) {
    pb.addEventListener('click', function () {
      document.body.classList.add('print-chart');
      window.print();
    });
    window.addEventListener('afterprint', function () { document.body.classList.remove('print-chart'); });
  }
  setUnit('metric');
})();
